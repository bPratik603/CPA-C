#include <stdio.h> 
#include <stdlib.h> 

int num = 10; 

int main(void){
	printf("Hello,World\n"); 
	printf("num = %d\n", num); 
	exit(0); 
}
