#include <stdio.h> 
#include <stdlib.h> 

#define MY_NUMBER   500 

int main(void)
{
    printf("NUMBER = %d\n", 500); 
    printf("NUMBER = %d\n", MY_NUMBER); 
    return (0); 
}