int printf(const char* fmt, ...); 
void exit(int); 
int puts(const char*); 

int num1 = 0, num2 = 0, summation = 0; 

int main(void)
{
	num1 = 100; 
	num2 = 200; 
	summation = num1 + num2; 
	printf("%d + %d = %d\n", num1, num2, summation); 
	puts("C VERSION:Roll No:143:Kartik Patil: Sniper"); 
	exit(0); 
}

/* 
 	bicycle -> Machine 
	geared two wheeler -> Assembly 
	non-geared two wheeler -> C 
	geared four wheeler -> java / C# 
	auto transmission -> Python / Perl / PHP 

	auto driver -> MSCIT 
*/ 
