#include <stdio.h> 

int main(void){
	printf("sizeof(long)=%zu\n", sizeof(long)); 
	return (0); 
}
