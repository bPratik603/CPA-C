#ifndef _MY_HEADER_H 
#define _MY_HEADER_H 

static inline int my_square(int n){
	return (n * n); 
}


#endif 
